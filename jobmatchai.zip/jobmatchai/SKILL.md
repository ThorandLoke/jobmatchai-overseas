---
name: jobmatchai
description: "AI job matching assistant - resume analysis, job search across Germany/Sweden/Denmark/USA, auto cover letter"
description_zh: "AI智能求职助手 - 一键完成简历优化和职位申请"
description_en: "AI job matching assistant - auto career, job search, resume optimization"
---

# JobMatchAI - 智能求职助手

## 功能概述

这个Skill帮助用户：
1. **扫描本地简历** - 自动查找并解析PDF/DOCX简历
2. **分析简历** - 提取技能、经验、语言能力，提供精修建议
3. **全网职位搜索** - 集成多个国家的招聘API
4. **自动生成求职信** - 根据职位语言生成英/德/丹/瑞典语求职信

## 触发关键词

- auto career
- auto job  
- job search
- resume help
- cover letter
- find job
- 帮我找工作
- 分析我的简历

## 工作流程

### 1. 简历扫描

用户简历通常位于：
- `~/Downloads/` 目录下
- `~/Documents/Resume/` 
- `~/Desktop/`

常见文件名模式：`CV*.pdf`, `Resume*.docx`, `简历*.pdf`

### 2. 职位搜索API

已集成的API：

| 国家 | API | 状态 | 语言 |
|------|-----|------|------|
| 🇩🇪 德国 | Arbeitsagentur | ✅ 可用 | 德语 |
| 🇸🇪 瑞典 | Jobtechdev | ✅ 可用 | 瑞典语 |
| 🇩🇰 丹麦 | Jobinsats | ⚠️ 申请中 | 丹麦语 |
| 🇺🇸 美国 | USAJOBS | ⚠️ 需API Key | 英语 |

**注意**：USAJOBS需要用户自己申请API Key：
1. 访问 https://developer.usajobs.gov/apirequest/
2. 注册并获取API Key
3. 设置环境变量 `export USAJOBS_API_KEY="你的key"`

### 3. 求职信生成

根据职位发布语言自动选择：
- 德国职位 → 德语求职信
- 丹麦职位 → 丹麦语或英语（跨国公司用英语）
- 瑞典职位 → 瑞典语
- 美国职位 → 英语

## 快速开始

### 启动后端服务

```bash
cd /Users/weili/WorkBuddy/Claw/JobMatchAI/backend
python main.py
```

后端运行在 `http://localhost:8000`

### 启动前端

需要单独启动HTTP服务器：

```bash
# 方法1: Python
cd /Users/weili/WorkBuddy/Claw/JobMatchAI/frontend
python -m http.server 8080

# 方法2: Node
npx serve -p 8080
```

访问 `http://localhost:8080`

## 核心文件

- `backend/main.py` - FastAPI后端，包含所有API端点
- `frontend/index.html` - 用户界面
- `references/api_docs.md` - 各API详细文档

## 注意事项

1. Indeed Publisher API 可从 https://www.indeed.com/publisher 申请
2. 德国API不需要认证，直接可用
3. 瑞典API不需要认证，直接可用
4. 丹麦Jobinsats已发送申请，等待回复
