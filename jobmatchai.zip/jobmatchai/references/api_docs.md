# JobMatchAI API Documentation

## 后端API端点

### 1. 根路径
```
GET /
返回: { message, status, endpoints }
```

### 2. 健康检查
```
GET /health
返回: { status: "healthy" }
```

### 3. 上传简历
```
POST /upload-resume
Content-Type: multipart/form-data
参数: file (PDF/DOCX/TXT)

返回: { success, filename, content }
```

### 4. 分析简历
```
POST /analyze-resume
Content-Type: multipart/form-data OR application/x-www-form-urlencoded

参数 (二选一):
- file: 上传简历文件
- resume_text: 直接传递文本

返回: { success, text_preview, analysis: { skills, experience, languages, summary, suggestions } }
```

### 5. 搜索职位
```
POST /search-jobs
Content-Type: application/x-www-form-urlencoded

参数:
- resume_text: 简历内容（用于计算匹配度）
- keywords: 搜索关键词（可选，默认根据简历提取）
- countries: 目标国家，逗号分隔（可选，默认all）

支持的国家代码:
- all, germany, de
- sweden, sv
- denmark, dk
- usa, us

返回: { total, jobs: [{ title, company, location, url, date, source, match_score, language }] }
```

### 6. 生成求职信
```
POST /generate-cover-letter
Content-Type: application/x-www-form-urlencoded

参数:
- resume_text: 简历内容
- job_title: 职位名称
- job_company: 公司名称
- job_location: 工作地点（可选）
- language: 求职信语言 (en/da/de/sv)

返回: { success, letter, language, job }
```

---

## 各国API详情

### 德国 - Arbeitsagentur

**端点**: `https://rest.arbeitsagentur.de/jobboerse/jobsuche-service/pc/v4/jobs`

**认证**: `X-API-Key: jobboerse-jobsuche`

**参数**:
- `was`: 关键词
- `wo`: 地点
- `size`: 结果数量
- `page`: 页码

**返回字段**:
- `titel`: 职位标题
- `arbeitgeber`: 公司名
- `arbeitsort.ort`: 工作地点
- `externeUrl`: 职位链接
- `aktuelleVeroeffentlichungsdatum`: 发布日期

---

### 瑞典 - Jobtechdev

**端点**: `https://jobsearch.api.jobtechdev.se/search`

**认证**: 无

**参数**:
- `q`: 搜索关键词
- `limit`: 结果数量

**返回字段**:
- `headline`: 职位标题
- `employer.name`: 公司名
- `workplace_address.address`: 工作地点
- `web_url`: 职位链接
- `publication_date`: 发布日期

---

### 美国 - USAJOBS

**端点**: `https://data.usajobs.gov/api/Search`

**认证**: `Authorization-Key: API_KEY`

**参数**:
- `Keyword`: 关键词
- `LocationName`: 地点
- `ResultsPerPage`: 数量 (最大500)
- `Fields`: 返回字段级别 (Min/Full)

**返回字段**:
- `PositionTitle`: 职位标题
- `DepartmentName`: 部门/公司
- `PositionLocationDisplay`: 工作地点
- `PositionURI`: 职位链接
- `PublicationStartDate`: 发布日期

**申请API Key**: https://developer.usajobs.gov/apirequest/

---

### 丹麦 - Jobinsats

**状态**: 等待API接入

**申请邮件**: wei.li@outlook.dk
