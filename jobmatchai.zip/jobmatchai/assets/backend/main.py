"""
JobMatchAI Backend - FastAPI
完整的后端服务：简历解析 + 职位搜索 + 求职信生成
"""
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional
import subprocess
import json
import re
import io
import uvicorn
import os

app = FastAPI(title="JobMatchAI API", version="1.0.0")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === 数据模型 ===
class Job(BaseModel):
    title: str
    company: str
    location: str
    url: str
    date: str
    source: str
    match_score: int = 0
    language: str = "en"  # 职位语言：en, da, de, sv

class ResumeAnalysis(BaseModel):
    skills: List[str]
    experience: List[dict]
    languages: List[str]
    summary: str

class CoverLetterRequest(BaseModel):
    resume_text: str
    job: Job
    language: str = "en"  # en, da, de, sv

# === 简历解析 ===
def parse_resume(file_content: bytes, filename: str) -> str:
    """解析简历文件"""
    text = ""
    
    try:
        if filename.endswith('.pdf'):
            # 尝试用PyPDF2解析
            try:
                from PyPDF2 import PdfReader
                reader = PdfReader(io.BytesIO(file_content))
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            except:
                # 备用：用curl调用外部PDF解析
                pass
                
        elif filename.endswith('.docx') or filename.endswith('.doc'):
            # 用python-docx解析
            try:
                import docx
                doc = docx.Document(io.BytesIO(file_content))
                for para in doc.paragraphs:
                    text += para.text + "\n"
            except:
                pass
        
        elif filename.endswith('.txt'):
            # 纯文本文件
            try:
                text = file_content.decode('utf-8', errors='ignore')
            except:
                pass
                
    except Exception as e:
        print(f"解析错误: {e}")
        
    return text

# === AI分析简历（模拟版）===
def analyze_resume(text: str) -> dict:
    """分析简历，提取技能和经验"""
    text_lower = text.lower()
    
    # 技能关键词
    skill_keywords = {
        'ERP': ['erp', 'sap', 'dynamics ax', 'dynamics 365', 'd365', 'netsuite', 'oracle', 'sap business one'],
        '编程': ['python', 'javascript', 'java', 'c#', 'sql', 'programming', 'coding'],
        '项目管理': ['project management', '项目管理', 'scrum', 'agile', 'prince2'],
        '财务': ['finance', 'accounting', '财务', 'cpa', 'cfa', 'budgeting'],
        '供应链': ['supply chain', '供应链', 'logistics', 'procurement', 'warehouse'],
        '微软产品': ['microsoft', 'office', 'excel', 'power bi', 'azure'],
        '数据': ['data analysis', '数据分析', 'bi', 'reporting', 'dashboard'],
    }
    
    found_skills = []
    for category, keywords in skill_keywords.items():
        for kw in keywords:
            if kw in text_lower:
                found_skills.append(category)
                break
    
    # 提取工作经历（简单模拟）
    experience = []
    exp_patterns = [
        r'(\d{4})\s*[-–]\s*(\d{4}|now|præsent)',
        r'(19|20)\d{2}\s*[-–]\s*(present|now)',
    ]
    
    # 公司/职位关键词
    companies = []
    job_titles = []
    
    # 简单提取
    common_jobs = ['consultant', '顾问', 'manager', '经理', 'analyst', '工程师', 'developer', 'director']
    for job in common_jobs:
        if job in text_lower:
            job_titles.append(job.title())
    
    # 语言能力
    languages = []
    lang_keywords = {
        '中文': ['中文', 'chinese', 'mandarin'],
        '英语': ['english', '英语', 'cet-', 'ielts', 'toefl'],
        '丹麦语': ['dansk', 'danish', '丹麦语'],
        '德语': ['german', 'deutsch', '德语'],
        '瑞典语': ['swedish', 'svenska', '瑞典语']
    }
    
    for lang, keywords in lang_keywords.items():
        for kw in keywords:
            if kw in text_lower:
                languages.append(lang)
                break
    
    # 生成改进建议
    suggestions = []
    
    if len(text.split('\n')) < 10:
        suggestions.append("📝 建议增加更多工作经历详情，包括具体职责和成就")
    
    if not any(kw in text_lower for kw in ['achievement', 'accomplish', 'result', 'impact', 'improved', 'saved']):
        suggestions.append("💡 建议在工作经历中添加可量化的成果，如'提升效率30%'或'节约成本50万'")
    
    if 'summary' not in text_lower and 'objective' not in text_lower:
        suggestions.append("👤 建议添加个人简介/职业目标，让招聘方快速了解你的价值定位")
    
    if len(found_skills) < 3:
        suggestions.append("🔧 建议列出更多技术技能，特别是与目标职位相关的工具和软件")
    
    if not any(kw in text_lower for kw in ['certification', 'certificate', '培训', 'certified']):
        suggestions.append("📜 建议添加相关认证和培训经历，如PMP、SCMP等")
    
    if len(text.split()) < 150:
        suggestions.append("📄 简历内容偏少，建议丰富到300-500词以更好地展示经验")
    
    if not suggestions:
        suggestions.append("✅ 简历结构良好！建议检查格式和关键词优化")
    
    return {
        'skills': list(set(found_skills)) if found_skills else ['ERP', '项目管理'],
        'experience': experience[:3],
        'languages': list(set(languages)) if languages else ['中文', '英语'],
        'summary': f"拥有{len(found_skills)}项技能，{len(languages)}种语言能力",
        'suggestions': suggestions,
        'improved_text': None  # 后续可接入GPT生成精修版本
    }

# === 德国 API ===
def search_germany(keyword: str, location: str = "", limit: int = 10):
    """搜索德国职位"""
    url = "https://rest.arbeitsagentur.de/jobboerse/jobsuche-service/pc/v4/jobs"
    
    cmd = [
        "curl", "-s", "-X", "GET", url,
        "-H", "X-API-Key: jobboerse-jobsuche",
        "-H", "Accept: application/json",
        f"--data-urlencode", f"was={keyword}",
        f"--data-urlencode", f"wo={location}",
        f"--data-urlencode", f"size={limit}",
        f"--data-urlencode", "page=1"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        data = json.loads(result.stdout)
        
        jobs = []
        if "stellenangebote" in data:
            for j in data["stellenangebote"]:
                jobs.append(Job(
                    title=j.get("titel", j.get("beruf", "")),
                    company=j.get("arbeitgeber", "N/A"),
                    location=j.get("arbeitsort", {}).get("ort", ""),
                    url=j.get("externeUrl", ""),
                    date=j.get("aktuelleVeroeffentlichungsdatum", ""),
                    source="🇩🇪 Germany",
                    language="de"  # 德国职位用德语
                ))
        return jobs
    except Exception as e:
        print(f"Germany API Error: {e}")
        return []

# === 瑞典 API ===
def search_sweden(keyword: str, location: str = "", limit: int = 10):
    """搜索瑞典职位"""
    import requests
    
    url = "https://jobsearch.api.jobtechdev.se/search"
    params = {"q": keyword, "limit": limit}
    
    try:
        r = requests.get(url, params=params, timeout=10)
        data = r.json()
        
        jobs = []
        if "hits" in data:
            for j in data["hits"]:
                employer_name = j.get("employer", {})
                if isinstance(employer_name, dict):
                    employer_name = employer_name.get("name", "N/A")
                else:
                    employer_name = str(employer_name)
                
                jobs.append(Job(
                    title=j.get("headline", ""),
                    company=employer_name,
                    location=j.get("workplace_address", {}).get("address", ""),
                    url=j.get("web_url", ""),
                    date=j.get("publication_date", ""),
                    source="🇸🇪 Sweden",
                    language="sv"  # 瑞典职位用瑞典语
                ))
        return jobs
    except Exception as e:
        print(f"Sweden API Error: {e}")
        return []

# === 美国 USAJOBS API ===
def search_usa(keyword: str, location: str = "", limit: int = 10):
    """搜索美国政府职位 - USAJOBS API"""
    import requests
    
    # 从环境变量获取API Key，或者使用示例key（用户需要替换为自己的）
    API_KEY = os.environ.get("USAJOBS_API_KEY", "")
    
    if not API_KEY:
        # 如果没有API Key，返回提示信息
        return []
    
    url = "https://data.usajobs.gov/api/Search"
    params = {
        "Keyword": keyword,
        "ResultsPerPage": min(limit, 500),
        "Fields": "full"
    }
    if location:
        params["LocationName"] = location
    
    headers = {
        "Authorization-Key": API_KEY,
        "User-Agent": "JobMatchAI/1.0 (contact@example.com)"
    }
    
    try:
        r = requests.get(url, params=params, headers=headers, timeout=15)
        if r.status_code != 200:
            print(f"USAJOBS API Error: {r.status_code} - {r.text}")
            return []
        
        data = r.json()
        jobs = []
        
        if "SearchResult" in data:
            for item in data["SearchResult"].get("SearchResultItems", []):
                desc = item.get("MatchedObjectDescriptor", {})
                
                # 提取薪资信息
                remuneration = desc.get("PositionRemuneration", [{}])[0] if desc.get("PositionRemuneration") else {}
                salary = ""
                if remuneration:
                    min_sal = remuneration.get("MinimumRange", "")
                    max_sal = remuneration.get("MaximumRange", "")
                    if min_sal and max_sal:
                        salary = f"${min_sal}-${max_sal}"
                
                jobs.append(Job(
                    title=desc.get("PositionTitle", ""),
                    company=desc.get("DepartmentName", desc.get("OrganizationName", "US Government")),
                    location=desc.get("PositionLocationDisplay", ""),
                    url=desc.get("PositionURI", ""),
                    date=desc.get("PublicationStartDate", "")[:10] if desc.get("PublicationStartDate") else "",
                    source="🇺🇸 USAJOBS",
                    language="en"  # 美国职位用英语
                ))
        return jobs
    except Exception as e:
        print(f"USAJOBS API Error: {e}")
        return []

# === 丹麦职位（模拟）===
def search_denmark(keyword: str, location: str = "", limit: int = 10):
    """搜索丹麦职位 - 模拟数据（等API接入）"""
    # 模拟丹麦职位数据
    jobs = [
        Job(
            title="Dynamics 365 F&O Consultant",
            company="ITONICS",
            location="Copenhagen",
            url="https://jobindex.dk",
            date="2026-03-28",
            source="🇩🇰 Denmark",
            language="en"  # 丹麦英语职位
        ),
        Job(
            title="Senior NetSuite Consultant",
            company="Staria",
            location="Aarhus",
            url="https://staria.com/careers",
            date="2026-03-27",
            source="🇩🇰 Denmark",
            language="en"  # 跨国公司常用英语
        ),
        Job(
            title="ERP Implementation Consultant",
            company="BE-terna",
            location="Copenhagen",
            url="https://be-terna.com",
            date="2026-03-26",
            source="🇩🇰 Denmark",
            language="da"  # 丹麦语职位
        ),
        Job(
            title="D365 Finance Consultant",
            company="EG",
            location="Aarhus",
            url="https://eg.dk",
            date="2026-03-25",
            source="🇩🇰 Denmark",
            language="da"  # 丹麦语职位
        ),
    ]
    
    # 简单过滤
    keyword_lower = keyword.lower()
    filtered = [j for j in jobs if keyword_lower in j.title.lower() or keyword_lower in j.company.lower()]
    return filtered[:limit]

# === 匹配度计算 ===
def calculate_match_score(resume_text: str, job: Job) -> int:
    """计算简历与职位的匹配度"""
    text_lower = resume_text.lower()
    job_text = (job.title + " " + job.company).lower()
    
    score = 50  # 基础分
    
    # 关键词匹配
    keywords = ['erp', 'dynamics', 'ax', 'netsuite', 'oracle', 'sap', 'consultant', 'implementation']
    for kw in keywords:
        if kw in text_lower and kw in job_text:
            score += 10
        elif kw in job_text:
            score += 5
    
    return min(98, score)

# === 求职信生成 ===
def generate_cover_letter(resume_text: str, job: Job, language: str = "en") -> str:
    """生成求职信"""
    
    # 提取简历中的关键信息
    name = "Wei Li"
    text_lower = resume_text.lower()
    
    # 检测技能 - 根据语言选择
    skills = []
    if 'dynamics' in text_lower or 'ax' in text_lower:
        skills.append('Microsoft Dynamics AX/365')
    if 'netsuite' in text_lower:
        skills.append('Oracle NetSuite')
    if 'erp' in text_lower:
        if language == 'en':
            skills.append('ERP systems')
        elif language == 'da':
            skills.append('ERP-systemer')
        elif language == 'de':
            skills.append('ERP-Systeme')
        elif language == 'sv':
            skills.append('ERP-system')
        else:
            skills.append('ERP')
    if 'project' in text_lower:
        if language == 'en':
            skills.append('project management')
        elif language == 'da':
            skills.append('projektledelse')
        elif language == 'de':
            skills.append('Projektmanagement')
        elif language == 'sv':
            skills.append('projektledning')
        else:
            skills.append('project management')
    
    # 语言设置
    lang_config = {
        'en': {'dear': 'Dear Hiring Manager', 'sign': 'Best regards'},
        'da': {'dear': 'Kære Rekrutteringsansvarlig', 'sign': 'Med venlig hilsen'},
        'de': {'dear': 'Sehr geehrte Damen und Herren', 'sign': 'Mit freundlichen Grüßen'},
        'sv': {'dear': 'Till rekryterare', 'sign': 'Med vänliga hälsningar'},
    }
    
    config = lang_config.get(language, lang_config['en'])
    
    # 生成求职信
    if language == 'en':
        letter = f"""{config['dear']},

I am writing to apply for the {job.title} position at {job.company}.

About Me:
I have extensive experience in ERP implementation, specializing in Microsoft Dynamics AX/365 and Oracle NetSuite. My background includes:
- {', '.join(skills) if skills else 'ERP consulting'}
- Project management and implementation
- Cross-cultural communication

Why {job.company}:
I am attracted to {job.company} because of your innovative approach and strong market presence in the Nordic region. I believe my skills would be a great fit for your team.

I look forward to discussing how I can contribute to your organization.

{config['sign']},
{name}"""
    
    elif language == 'da':
        letter = f"""{config['dear']},

Jeg skriver for at søge stillingen som {job.title} hos {job.company}.

Om mig:
Jeg har omfattende erfaring med ERP-implementering, med fokus på Microsoft Dynamics AX/365 og Oracle NetSuite. Min baggrund inkluderer:
- {', '.join(skills) if skills else 'ERP-rådgivning'}
- Projektledelse og implementering
- Tværkulturel kommunikation

Hvorfor {job.company}:
Jeg er tiltrukket af {job.company} på grund af jeres innovative tilgang og stærke tilstedeværelse på det nordiske marked.

Jeg ser frem til at diskutere, hvordan jeg kan bidrage til jeres team.

{config['sign']},
{name}"""
    
    elif language == 'de':
        letter = f"""{config['dear']},

ich bewerbe mich um die Position als {job.title} bei {job.company}.

Über mich:
Ich verfüge über umfangreiche Erfahrung in der ERP-Implementierung, spezialisiert auf Microsoft Dynamics AX/365 und Oracle NetSuite. Mein Hintergrund umfasst:
- {', '.join(skills) if skills else 'ERP-Beratung'}
- Projektmanagement und Implementierung
- Interkulturelle Kommunikation

Warum {job.company}:
{job.company} reizt mich wegen Ihres innovativen Ansatzes und Ihrer starken Marktpräsenz in der nordischen Region.

Ich freue mich darauf, zu besprechen, wie ich zu Ihrem Team beitragen kann.

{config['sign']},
{name}"""
    
    elif language == 'sv':
        letter = f"""{config['dear']},

Jag skriver för att söka tjänsten som {job.title} hos {job.company}.

Om mig:
Jag har omfattande erfarenhet av ERP-implementering, med specialisering på Microsoft Dynamics AX/365 och Oracle NetSuite. Min bakgrund inkluderar:
- {', '.join(skills) if skills else 'ERP-konsultation'}
- Projektledning och implementering
- Interkulturell kommunikation

Varför {job.company}:
Jag lockas av {job.company} på grund av ert innovativa tillvägagångssätt och starka marknadsnärvaro i den nordiska regionen.

Jag ser fram emot att diskutera hur jag kan bidra till ert team.

{config['sign']},
{name}"""
    
    else:
        # 默认英文
        letter = f"""Dear Hiring Manager,

I am writing to apply for the {job.title} position at {job.company}.

Best regards,
{name}"""
    
    return letter

# === API 端点 ===

@app.get("/")
def root():
    return {
        "message": "JobMatchAI API v1.0", 
        "status": "running",
        "endpoints": ["/analyze-resume", "/search-jobs", "/generate-cover-letter"]
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/upload-resume")
async def upload_resume(file: UploadFile = File(...)):
    """上传简历文件，返回文本内容"""
    try:
        content = await file.read()
        text = parse_resume(content, file.filename)
        
        if not text:
            return JSONResponse(
                status_code=400,
                content={"error": "无法解析文件，请上传PDF或DOCX格式"}
            )
        
        return {
            "success": True,
            "filename": file.filename,
            "content": text
        }
        
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.post("/analyze-resume")
async def analyze_resume_endpoint(
    file: UploadFile = File(None),
    resume_text: str = Form(None),
):
    """分析简历 - 支持文件上传或文本输入"""
    try:
        # 优先使用文本输入
        if resume_text:
            text = resume_text
        elif file:
            content = await file.read()
            text = parse_resume(content, file.filename)
        else:
            return JSONResponse(status_code=400, content={"error": "请提供简历文件或文本"})
        
        if not text:
            return JSONResponse(
                status_code=400,
                content={"error": "无法解析文件，请上传PDF或DOCX格式"}
            )
        
        analysis = analyze_resume(text)
        
        return {
            "success": True,
            "filename": file.filename,
            "text_preview": text[:500] + "..." if len(text) > 500 else text,
            "analysis": analysis
        }
        
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.post("/search-jobs")
def search_jobs_endpoint(
    resume_text: str = Form(...),
    keywords: str = Form(""),
    countries: str = Form("all")
):
    """根据简历搜索匹配职位"""
    
    all_jobs = []
    
    # 根据简历内容扩展关键词
    if not keywords:
        keywords = "ERP consultant Dynamics AX NetSuite"
    
    # 搜索各国职位（支持逗号分隔）
    country_list = [c.strip().lower() for c in countries.split(',')]
    
    if "all" in country_list or "germany" in country_list or "de" in country_list:
        all_jobs.extend(search_germany(keywords, "", 5))
    
    if "all" in country_list or "sweden" in country_list or "sv" in country_list:
        all_jobs.extend(search_sweden(keywords, "", 5))
    
    if "all" in country_list or "denmark" in country_list or "dk" in country_list or "danmark" in country_list:
        all_jobs.extend(search_denmark(keywords, "", 5))
    
    if "all" in country_list or "usa" in country_list or "us" in country_list or "united states" in country_list:
        all_jobs.extend(search_usa(keywords, "", 5))
    
    # 计算匹配度
    for job in all_jobs:
        job.match_score = calculate_match_score(resume_text, job)
    
    # 按匹配度排序
    all_jobs.sort(key=lambda x: x.match_score, reverse=True)
    
    return {
        "total": len(all_jobs),
        "jobs": [
            {
                "title": j.title,
                "company": j.company,
                "location": j.location,
                "url": j.url,
                "date": j.date,
                "source": j.source,
                "match_score": j.match_score,
                "language": j.language
            }
            for j in all_jobs[:10]
        ]
    }

@app.post("/generate-cover-letter")
def generate_cover_letter_endpoint(
    resume_text: str = Form(...),
    job_title: str = Form(...),
    job_company: str = Form(...),
    job_location: str = Form(""),
    language: str = Form("en")
):
    """生成求职信"""
    
    job = Job(
        title=job_title,
        company=job_company,
        location=job_location,
        url="",
        date="",
        source=""
    )
    
    letter = generate_cover_letter(resume_text, job, language)
    
    return {
        "success": True,
        "letter": letter,
        "language": language,
        "job": {
            "title": job_title,
            "company": job_company
        }
    }

# === 启动命令 ===
if __name__ == "__main__":
    print("🚀 JobMatchAI Backend 启动中...")
    print("📍 地址: http://localhost:8000")
    print("📚 API文档: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
