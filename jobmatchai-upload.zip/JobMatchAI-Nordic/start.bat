@echo off
chcp 65001 >nul
:: JobMatchAI Beta 启动脚本 (Windows)

echo 🚀 JobMatchAI Beta 启动器
echo ==========================

:: 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python
    echo 请访问 https://www.python.org/downloads/ 安装 Python 3.8+
    pause
    exit /b 1
)

echo ✅ Python 已安装

:: 检查虚拟环境
if not exist "venv" (
    echo 📦 创建虚拟环境...
    python -m venv venv
)

:: 激活虚拟环境
echo 🔧 激活虚拟环境...
call venv\Scripts\activate.bat

:: 安装依赖
echo 📥 安装依赖...
pip install -q fastapi uvicorn python-multipart python-docx PyMuPDF requests

:: 启动服务
echo.
echo 🎉 启动 JobMatchAI...
echo 📱 请在浏览器访问: http://localhost:8000
echo.
echo 按 Ctrl+C 停止服务
echo ==========================

cd backend
python main.py

pause
