#!/bin/bash
# JobMatchAI Beta 启动脚本 (Mac/Linux)

echo "🚀 JobMatchAI Beta 启动器"
echo "=========================="

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未检测到 Python3"
    echo "请访问 https://www.python.org/downloads/ 安装 Python 3.8+"
    exit 1
fi

echo "✅ Python 版本: $(python3 --version)"

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "📦 创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
echo "🔧 激活虚拟环境..."
source venv/bin/activate

# 安装依赖
echo "📥 安装依赖..."
pip install -q fastapi uvicorn python-multipart python-docx PyMuPDF requests

# 启动服务
echo ""
echo "🎉 启动 JobMatchAI..."
echo "📱 请在浏览器访问: http://localhost:8000"
echo ""
echo "按 Ctrl+C 停止服务"
echo "=========================="

cd backend
python main.py
