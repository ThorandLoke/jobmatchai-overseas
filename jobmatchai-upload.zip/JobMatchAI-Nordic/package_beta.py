#!/usr/bin/env python3
"""
JobMatchAI Beta 打包脚本
生成可分享的测试版本
"""

import os
import shutil
import zipfile
from datetime import datetime

def package_beta():
    """打包Beta版本"""
    
    # 项目根目录
    base_dir = "/Users/weili/WorkBuddy/Claw/JobMatchAI-Nordic"
    
    # 创建临时目录
    beta_dir = os.path.join(base_dir, "JobMatchAI-Beta")
    
    # 清理旧文件
    if os.path.exists(beta_dir):
        shutil.rmtree(beta_dir)
    
    os.makedirs(beta_dir)
    
    print("📦 正在打包 JobMatchAI Beta 版本...")
    print("=" * 50)
    
    # 复制文件
    files_to_copy = [
        ("backend/main.py", "backend/main.py"),
        ("backend/email_reader.py", "backend/email_reader.py"),
        ("backend/smart_matcher.py", "backend/smart_matcher.py"),
        ("backend/onboarding.py", "backend/onboarding.py"),
        ("frontend/index.html", "frontend/index.html"),
        ("frontend/onboarding.html", "frontend/onboarding.html"),
        ("start.sh", "start.sh"),
        ("start.bat", "start.bat"),
        ("README_BETA_TEST.md", "README.md"),
    ]
    
    for src, dst in files_to_copy:
        src_path = os.path.join(base_dir, src)
        dst_path = os.path.join(beta_dir, dst)
        
        # 创建目录
        os.makedirs(os.path.dirname(dst_path), exist_ok=True)
        
        if os.path.exists(src_path):
            shutil.copy2(src_path, dst_path)
            print(f"✅ {src}")
        else:
            print(f"⚠️  {src} 不存在，跳过")
    
    # 创建 requirements.txt
    requirements = """fastapi>=0.104.0
uvicorn>=0.24.0
python-multipart>=0.0.6
python-docx>=0.8.11
PyMuPDF>=1.23.0
requests>=2.31.0
openai>=1.0.0
"""
    
    with open(os.path.join(beta_dir, "requirements.txt"), "w") as f:
        f.write(requirements)
    print("✅ requirements.txt")
    
    # 创建 .gitignore
    gitignore = """venv/
__pycache__/
*.pyc
.DS_Store
user_profiles/
*.log
"""
    
    with open(os.path.join(beta_dir, ".gitignore"), "w") as f:
        f.write(gitignore)
    print("✅ .gitignore")
    
    # 设置启动脚本权限
    start_sh = os.path.join(beta_dir, "start.sh")
    if os.path.exists(start_sh):
        os.chmod(start_sh, 0o755)
        print("✅ 设置 start.sh 执行权限")
    
    # 创建 ZIP 文件
    zip_name = f"JobMatchAI-Beta-{datetime.now().strftime('%Y%m%d')}.zip"
    zip_path = os.path.join(os.path.expanduser("~/Downloads"), zip_name)
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(beta_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, beta_dir)
                zipf.write(file_path, arcname)
    
    print("=" * 50)
    print(f"🎉 Beta 版本打包完成！")
    print(f"📁 文件位置: {zip_path}")
    print(f"📦 文件大小: {os.path.getsize(zip_path) / 1024:.1f} KB")
    print("")
    print("分享方式:")
    print("1. 直接发送 ZIP 文件给朋友")
    print("2. 上传到 Google Drive / Dropbox 分享链接")
    print("3. 通过微信/邮件发送")
    print("")
    print("朋友收到后:")
    print("- Mac/Linux: 解压后运行 ./start.sh")
    print("- Windows: 解压后双击 start.bat")
    
    # 清理临时目录
    shutil.rmtree(beta_dir)
    
    return zip_path

if __name__ == "__main__":
    package_beta()
