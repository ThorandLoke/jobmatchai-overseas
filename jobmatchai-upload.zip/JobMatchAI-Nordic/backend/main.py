"""
JobMatchAI Nordic - 北欧华人求职助手
支持：中文、英文、丹麦语
核心功能：简历精修 + 邮件职位读取 + 求职信生成

Copyright © 2026 JobMatchAI. All rights reserved.
"""
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional, Dict
import uvicorn
import os
import re
import io
import json

# AI 配置 - 支持 OpenAI 和 Groq
try:
    from openai import OpenAI
    # 优先使用 Groq（免费），其次 OpenAI
    groq_api_key = os.getenv("GROQ_API_KEY")
    openai_api_key = os.getenv("OPENAI_API_KEY")
    
    if groq_api_key:
        ai_client = OpenAI(
            api_key=groq_api_key,
            base_url="https://api.groq.com/openai/v1"
        )
        AI_PROVIDER = "groq"
        AI_MODEL = "llama-3.1-70b-versatile"
        print("✅ Using Groq API (Free tier)")
    elif openai_api_key:
        ai_client = OpenAI(api_key=openai_api_key)
        AI_PROVIDER = "openai"
        AI_MODEL = "gpt-4o-mini"
        print("✅ Using OpenAI API")
    else:
        AI_PROVIDER = None
        print("⚠️ No AI API key found, using fallback mode")
        
    AI_AVAILABLE = AI_PROVIDER is not None
except Exception as e:
    AI_AVAILABLE = False
    AI_PROVIDER = None
    print(f"⚠️ AI client init failed: {e}, using fallback mode")

app = FastAPI(title="JobMatchAI Nordic API", version="2.0.0")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === 数据模型 ===
class Job(BaseModel):
    title: str
    company: str
    location: str
    description: str
    url: Optional[str] = ""
    source: str  # linkedin, jobindex, jobnet, etc.
    language: str = "da"  # zh, en, da

class ResumeAnalysis(BaseModel):
    skills: List[str]
    experience_years: int
    strengths: List[str]
    improvements: List[Dict]
    suggested_profile: str

# === 简历解析 ===
def parse_resume(file_content: bytes, filename: str) -> str:
    """解析简历文件 - PDF / DOCX / TXT"""
    text = ""
    filename_lower = filename.lower()
    
    try:
        if filename_lower.endswith('.pdf'):
            # 使用 pdfplumber 作为主要 PDF 解析器
            try:
                import pdfplumber
                with pdfplumber.open(io.BytesIO(file_content)) as pdf:
                    for page in pdf.pages:
                        t = page.extract_text()
                        if t:
                            text += t + "\n"
            except Exception as e1:
                print(f"pdfplumber failed: {e1}, trying PyPDF2...")
                # 备用：PyPDF2
                try:
                    from PyPDF2 import PdfReader
                    reader = PdfReader(io.BytesIO(file_content))
                    for page in reader.pages:
                        t = page.extract_text()
                        if t:
                            text += t + "\n"
                except Exception as e2:
                    print(f"PyPDF2 also failed: {e2}")
                            
        elif filename_lower.endswith('.docx'):
            try:
                import docx
                document = docx.Document(io.BytesIO(file_content))
                for para in document.paragraphs:
                    if para.text.strip():
                        text += para.text + "\n"
                for table in document.tables:
                    for row in table.rows:
                        row_texts = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                        if row_texts:
                            text += " | ".join(row_texts) + "\n"
            except Exception as e:
                print(f"DOCX解析失败: {e}")
        
        elif filename_lower.endswith('.txt'):
            for encoding in ['utf-8', 'utf-16', 'latin-1', 'gb18030']:
                try:
                    text = file_content.decode(encoding)
                    break
                except:
                    continue
                
    except Exception as e:
        print(f"解析错误: {e}")
    
    lines = [l for l in text.splitlines() if l.strip()]
    return "\n".join(lines)

# === 语言检测 ===
def detect_language(text: str) -> str:
    """检测文本语言：zh, en, da"""
    text = text[:1000]  # 只检查前1000字符
    
    # 检测丹麦语特征
    da_patterns = ['æ', 'ø', 'å', 'og', 'det', 'en', 'er', 'til', 'på', 'af']
    da_count = sum(1 for p in da_patterns if p in text.lower())
    
    # 检测中文字符
    zh_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    total_chars = len(text)
    
    if da_count >= 2:
        return 'da'
    elif zh_chars / max(total_chars, 1) > 0.1:
        return 'zh'
    else:
        return 'en'

# === AI 增强简历分析 ===
def analyze_resume_with_ai(text: str, lang: str = 'en') -> Dict:
    """使用 AI 深度分析简历"""
    if not AI_AVAILABLE:
        return analyze_resume_fallback(text, lang)
    
    try:
        prompts = {
            'zh': f"""请分析以下简历，以JSON格式返回：
{{
  "skills": ["技能1", "技能2"],
  "experience_years": 数字,
  "strengths": ["优势1", "优势2", "优势3"],
  "improvements": [
    {{"type": "weak_verb", "priority": "high/medium/low", "description": "问题描述", "suggestion": "改进建议"}}
  ],
  "suggested_profile": "建议的个人简介（50字以内）",
  "ats_score": 数字（1-100 ATS友好度评分）
}}

简历内容：
{text[:3000]}""",
            'en': f"""Please analyze this resume and return JSON:
{{
  "skills": ["skill1", "skill2"],
  "experience_years": number,
  "strengths": ["strength1", "strength2", "strength3"],
  "improvements": [
    {{"type": "weak_verb", "priority": "high/medium/low", "description": "issue", "suggestion": "improvement"}}
  ],
  "suggested_profile": "suggested profile summary (under 50 words)",
  "ats_score": number (1-100 ATS compatibility score)
}}

Resume:
{text[:3000]}""",
            'da': f"""Analyser dette CV og returner JSON:
{{
  "skills": ["kompetence1", "kompetence2"],
  "experience_years": tal,
  "strengths": ["styrke1", "styrke2", "styrke3"],
  "improvements": [
    {{"type": "weak_verb", "priority": "high/medium/low", "description": "problem", "suggestion": "forbedring"}}
  ],
  "suggested_profile": "foreslået profil (under 50 ord)",
  "ats_score": tal (1-100 ATS-score)
}}

CV:
{text[:3000]}"""
        }
        
        response = ai_client.chat.completions.create(
            model=AI_MODEL,
            messages=[
                {"role": "system", "content": "You are a professional resume analyzer. Return only valid JSON."},
                {"role": "user", "content": prompts.get(lang, prompts['en'])}
            ],
            temperature=0.3,
            max_tokens=1500
        )
        
        result = json.loads(response.choices[0].message.content)
        result['detected_language'] = lang
        result['ai_enhanced'] = True
        result['ai_provider'] = AI_PROVIDER
        return result
        
    except Exception as e:
        print(f"AI analysis failed: {e}, using fallback")
        return analyze_resume_fallback(text, lang)

def analyze_resume_fallback(text: str, lang: str = 'en') -> Dict:
    """本地规则分析（无需AI）"""
    # 技能关键词库（中英丹）
    skills_db = {
        'zh': ['Python', 'Java', 'ERP', 'NetSuite', 'Dynamics', '项目管理', '数据分析', 'SQL', '财务', '供应链'],
        'en': ['Python', 'Java', 'ERP', 'NetSuite', 'Dynamics', 'Project Management', 'Data Analysis', 'SQL', 'Finance', 'Supply Chain'],
        'da': ['Python', 'Java', 'ERP', 'NetSuite', 'Dynamics', 'Projektledelse', 'Dataanalyse', 'SQL', 'Finans', 'Forsyningskæde']
    }
    
    weak_verbs = {
        'zh': ['做了', '负责了', '参与了', '协助', '帮助'],
        'en': ['did', 'was responsible for', 'worked on', 'helped with', 'assisted'],
        'da': ['lavede', 'var ansvarlig for', 'arbejdede på', 'hjalp med', 'assisterede']
    }
    
    strong_verbs = {
        'zh': ['主导', '推动', '优化', '实现', '提升', '建立', '设计'],
        'en': ['led', 'implemented', 'optimized', 'achieved', 'improved', 'established', 'designed'],
        'da': ['ledede', 'implementerede', 'optimerede', 'opnåede', 'forbedrede', 'etablerede', 'designede']
    }
    
    text_lower = text.lower()
    detected_skills = [s for s in skills_db.get(lang, skills_db['en']) if s.lower() in text_lower]
    detected_weak = [v for v in weak_verbs.get(lang, weak_verbs['en']) if v in text_lower]
    
    improvements = []
    if detected_weak:
        improvements.append({
            'type': 'weak_verb',
            'priority': 'high',
            'description': {'zh': f'检测到 {len(detected_weak)} 处可强化的动词', 'en': f'Found {len(detected_weak)} weak verbs', 'da': f'Fandt {len(detected_weak)} svage verber'}.get(lang, 'Found weak verbs'),
            'suggestion': {'zh': '使用更强动词如"主导"、"实现"', 'en': 'Use stronger verbs like "led", "achieved"', 'da': 'Brug stærkere verber'}.get(lang, 'Use stronger verbs')
        })
    
    years = re.findall(r'(\d+)\s*(?:年|years?|år)', text_lower)
    exp_years = max([int(y) for y in years] + [0])
    
    profile_templates = {
        'zh': f'拥有{exp_years}年ERP系统实施经验，精通NetSuite和Dynamics AX。',
        'en': f'Experienced ERP professional with {exp_years}+ years in NetSuite and Dynamics AX.',
        'da': f'Erfaren ERP-professionel med {exp_years}+ års erfaring i NetSuite og Dynamics AX.'
    }
    
    return {
        'skills': detected_skills,
        'experience_years': exp_years,
        'strengths': detected_skills[:3] if detected_skills else ['ERP', 'Project Management'],
        'improvements': improvements,
        'suggested_profile': profile_templates.get(lang, profile_templates['en']),
        'ats_score': 70,
        'detected_language': lang,
        'ai_enhanced': False
    }

# 保持向后兼容
analyze_resume = analyze_resume_with_ai

# === AI 增强求职信生成 ===
def generate_cover_letter_with_ai(resume_text: str, job: Dict, lang: str = 'en') -> str:
    """使用 AI 生成高质量求职信"""
    if not AI_AVAILABLE:
        return generate_cover_letter_fallback(resume_text, job, lang)
    
    try:
        prompts = {
            'zh': f"""基于以下简历和职位信息，写一封专业的求职信（300-400字）：

简历亮点：
{resume_text[:1500]}

职位信息：
- 公司：{job.get('company', '')}
- 职位：{job.get('title', '')}
- 要求：{job.get('description', '')[:800]}

要求：
1. 突出简历中与职位匹配的经验
2. 使用专业但真诚的语气
3. 结构：开头（表达兴趣）→ 中间（匹配点）→ 结尾（行动号召）
4. 直接返回求职信正文，不要JSON""",
            'en': f"""Write a professional cover letter (300-400 words) based on:

Resume highlights:
{resume_text[:1500]}

Job details:
- Company: {job.get('company', '')}
- Position: {job.get('title', '')}
- Requirements: {job.get('description', '')[:800]}

Requirements:
1. Highlight relevant experience matching the job
2. Professional yet genuine tone
3. Structure: Opening → Body (match points) → Closing (call to action)
4. Return only the cover letter text, no JSON""",
            'da': f"""Skriv en professionel ansøgning (300-400 ord) baseret på:

CV-højdepunkter:
{resume_text[:1500]}

Jobdetaljer:
- Virksomhed: {job.get('company', '')}
- Stilling: {job.get('title', '')}
- Krav: {job.get('description', '')[:800]}

Krav:
1. Fremhæv relevant erfaring der matcher jobbet
2. Professionel men oprigtig tone
3. Struktur: Indledning → Hoveddel → Afslutning
4. Returner kun ansøgningsteksten, ingen JSON"""
        }
        
        response = ai_client.chat.completions.create(
            model=AI_MODEL,
            messages=[
                {"role": "system", "content": "You are a professional career coach who writes compelling cover letters."},
                {"role": "user", "content": prompts.get(lang, prompts['en'])}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        letter = response.choices[0].message.content.strip()
        return letter
        
    except Exception as e:
        print(f"AI cover letter failed: {e}, using fallback")
        return generate_cover_letter_fallback(resume_text, job, lang)

def generate_cover_letter_fallback(resume_text: str, job: Dict, lang: str = 'en') -> str:
    """模板生成（无需AI）"""
    templates = {
        'zh': f"""尊敬的招聘经理，

您好！我在{job.get('source', '招聘网站')}上看到贵公司{job.get('company', '')}的{job.get('title', '')}职位，对此非常感兴趣。

基于我的简历，我拥有丰富的相关经验，相信能为贵公司带来价值。

职位要求：
{job.get('description', '')[:500]}...

期待有机会与您进一步交流。

此致
敬礼！

[您的姓名]""",
        'en': f"""Dear Hiring Manager,

I am writing to express my strong interest in the {job.get('title', '')} position at {job.get('company', '')}.

Based on my experience outlined in my resume, I am confident that I can bring significant value to your team.

Job Requirements:
{job.get('description', '')[:500]}...

I look forward to discussing how my skills align with your needs.

Best regards,

[Your Name]""",
        'da': f"""Kære HR-afdeling,

Jeg skriver for at udtrykke min interesse for stillingen som {job.get('title', '')} hos {job.get('company', '')}.

Baseret på min erfaring beskrevet i mit CV er jeg overbevist om, at jeg kan bidrage til jeres team.

Jobkrav:
{job.get('description', '')[:500]}...

Jeg ser frem til at diskutere, hvordan mine kompetencer matcher jeres behov.

Med venlig hilsen,

[Navn]"""
    }
    return templates.get(lang, templates['en'])

# 保持向后兼容
generate_cover_letter = generate_cover_letter_with_ai

# === API端点 ===

@app.get("/")
def read_root():
    """返回前端页面"""
    frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
    if os.path.exists(frontend_path):
        return FileResponse(frontend_path)
    return {"message": "JobMatchAI Nordic API", "version": "2.0.0"}

@app.get("/health")
def health_check():
    """健康检查"""
    return {"status": "ok", "service": "JobMatchAI Nordic"}

@app.post("/upload-resume")
async def upload_resume(file: UploadFile = File(...)):
    """上传并解析简历"""
    try:
        content = await file.read()
        text = parse_resume(content, file.filename)
        lang = detect_language(text)
        
        return {
            "success": True,
            "filename": file.filename,
            "text": text,
            "detected_language": lang,
            "language_name": {"zh": "中文", "en": "English", "da": "Dansk"}.get(lang, "English")
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/analyze-resume")
async def analyze_resume_endpoint(
    resume_text: str = Form(...),
    language: str = Form("auto")
):
    """分析简历并返回改进建议"""
    try:
        if language == "auto":
            lang = detect_language(resume_text)
        else:
            lang = language
        
        analysis = analyze_resume(resume_text, lang)
        
        return {
            "success": True,
            "analysis": analysis,
            "detected_language": lang
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/generate-cover-letter")
async def generate_cover_letter_endpoint(
    resume_text: str = Form(...),
    job_title: str = Form(...),
    company: str = Form(...),
    job_description: str = Form(...),
    language: str = Form("da")
):
    """生成求职信"""
    try:
        job = {
            "title": job_title,
            "company": company,
            "description": job_description,
            "source": "User Input"
        }
        
        cover_letter = generate_cover_letter(resume_text, job, language)
        
        return {
            "success": True,
            "cover_letter": cover_letter,
            "language": language
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.get("/detect-job-language")
def detect_job_language_endpoint(text: str):
    """检测职位描述语言"""
    lang = detect_language(text)
    return {
        "language": lang,
        "language_name": {"zh": "中文", "en": "English", "da": "Dansk"}.get(lang, "English")
    }


# === 智能职位匹配 API（新增）===

from smart_matcher import UserProfileManager, SmartJobMatcher, AutoJobProcessor
from email_reader import JobEmailReader

# 初始化管理器
profile_manager = UserProfileManager()
job_matcher = SmartJobMatcher(profile_manager)
auto_processor = AutoJobProcessor(profile_manager, job_matcher)

class EmailConfig(BaseModel):
    email: str
    password: str
    imap_server: Optional[str] = None

class JobAction(BaseModel):
    user_id: str
    job: Dict
    action: str  # 'view', 'save', 'apply', 'ignore'

@app.post("/user-profile/create")
async def create_user_profile(user_id: str = Form(...), resume_text: str = Form(...)):
    """从简历创建用户画像"""
    try:
        profile = profile_manager.create_profile(user_id, resume_text)
        return {
            "success": True,
            "profile": {
                "user_id": profile.user_id,
                "skills": profile.skills,
                "total_years": profile.total_years,
                "industries": profile.industries,
                "roles": profile.roles
            }
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.get("/user-profile/{user_id}")
async def get_user_profile(user_id: str):
    """获取用户画像"""
    profile = profile_manager.get_profile(user_id)
    if not profile:
        return {"success": False, "error": "Profile not found"}
    
    return {
        "success": True,
        "profile": profile.to_dict()
    }

@app.post("/user-profile/update-from-resume")
async def update_profile_from_resume(user_id: str = Form(...), resume_text: str = Form(...)):
    """根据更新的简历刷新用户画像"""
    try:
        profile = profile_manager.update_profile_from_resume(user_id, resume_text)
        return {
            "success": True,
            "profile": {
                "user_id": profile.user_id,
                "skills": profile.skills,
                "total_years": profile.total_years,
                "updated_at": profile.updated_at
            }
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/jobs/fetch-from-email")
async def fetch_jobs_from_email(config: EmailConfig):
    """从用户邮箱读取招聘邮件"""
    try:
        reader = JobEmailReader(
            email_address=config.email,
            password=config.password,
            imap_server=config.imap_server
        )
        
        jobs = reader.fetch_job_emails(limit=50)
        reader.disconnect()
        
        return {
            "success": True,
            "count": len(jobs),
            "jobs": jobs
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/jobs/match")
async def match_jobs_endpoint(
    user_id: str = Form(...),
    jobs: str = Form(...)  # JSON字符串
):
    """智能匹配职位"""
    try:
        jobs_list = json.loads(jobs)
        matched_jobs = job_matcher.filter_and_rank_jobs(user_id, jobs_list, min_score=60.0)
        
        return {
            "success": True,
            "total": len(jobs_list),
            "matched": len(matched_jobs),
            "jobs": matched_jobs
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/jobs/process-email-batch")
async def process_email_batch(
    user_id: str = Form(...),
    email_config: str = Form(...)  # JSON字符串
):
    """一键处理：读取邮件 → 智能筛选 → 返回匹配职位"""
    try:
        config = json.loads(email_config)
        
        # 1. 读取邮件
        reader = JobEmailReader(
            email_address=config['email'],
            password=config['password'],
            imap_server=config.get('imap_server')
        )
        jobs = reader.fetch_job_emails(limit=50)
        reader.disconnect()
        
        # 2. 智能筛选
        result = auto_processor.process_email_jobs(user_id, jobs)
        
        # 3. 生成每日摘要
        digest = auto_processor.generate_daily_digest(user_id, jobs)
        
        return {
            "success": True,
            "summary": result['summary'],
            "high_match": result['high_match'],
            "medium_match": result['medium_match'],
            "digest": digest
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@app.post("/jobs/action")
async def record_job_action(action: JobAction):
    """记录用户对职位的操作（用于学习偏好）"""
    try:
        profile_manager.learn_from_job_action(action.user_id, action.job, action.action)
        return {"success": True, "message": f"Recorded {action.action} action"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# === 启动 ===
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
