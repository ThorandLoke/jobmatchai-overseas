"""
JobMatchAI 智能引导系统
自动发现简历 → 智能精修 → 连接招聘平台 → 一键求职
"""

import os
import re
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import json

@dataclass
class ResumeFile:
    """简历文件信息"""
    path: str
    filename: str
    modified_time: datetime
    language: str  # 'zh', 'en', 'da'
    type: str  # 'pdf', 'docx', 'txt'
    
    @property
    def display_name(self) -> str:
        return f"{self.filename} ({self.modified_time.strftime('%Y-%m-%d')})"


class ResumeDiscovery:
    """自动发现用户电脑中的简历"""
    
    # 简历文件名关键词（中英文）
    RESUME_KEYWORDS = [
        'cv', 'resume', '简历', 'curriculum',
        'ansøgning',  # 丹麦语求职信
        'ansoegning',
    ]
    
    # 忽略的文件夹
    IGNORE_PATTERNS = [
        'node_modules', '.git', '__pycache__', '.venv', 'venv',
        'Applications', 'Library', 'System', '.Trash'
    ]
    
    def __init__(self, home_dir: str = None):
        self.home_dir = home_dir or os.path.expanduser('~')
        self.common_paths = [
            'Downloads',
            'Documents',
            'Desktop',
            'Dropbox',
            'OneDrive',
            'Google Drive',
        ]
    
    def find_resumes(self, max_depth: int = 3) -> List[ResumeFile]:
        """
        扫描常见目录寻找简历文件
        返回按修改时间排序的简历列表
        """
        resumes = []
        
        for folder in self.common_paths:
            path = os.path.join(self.home_dir, folder)
            if os.path.exists(path):
                resumes.extend(self._scan_directory(path, max_depth))
        
        # 按修改时间倒序排列（最新的在前）
        resumes.sort(key=lambda x: x.modified_time, reverse=True)
        return resumes
    
    def _scan_directory(self, path: str, max_depth: int, current_depth: int = 0) -> List[ResumeFile]:
        """递归扫描目录"""
        if current_depth >= max_depth:
            return []
        
        resumes = []
        
        try:
            for item in os.listdir(path):
                # 忽略隐藏文件和系统文件夹
                if item.startswith('.') or item in self.IGNORE_PATTERNS:
                    continue
                
                full_path = os.path.join(path, item)
                
                if os.path.isdir(full_path):
                    resumes.extend(self._scan_directory(full_path, max_depth, current_depth + 1))
                elif self._is_resume_file(item):
                    resume = self._create_resume_info(full_path)
                    if resume:
                        resumes.append(resume)
        
        except PermissionError:
            pass  # 忽略无权限访问的文件夹
        
        return resumes
    
    def _is_resume_file(self, filename: str) -> bool:
        """判断文件是否为简历"""
        filename_lower = filename.lower()
        
        # 检查扩展名
        if not filename_lower.endswith(('.pdf', '.docx', '.doc', '.txt')):
            return False
        
        # 检查文件名是否包含简历关键词
        for keyword in self.RESUME_KEYWORDS:
            if keyword.lower() in filename_lower:
                return True
        
        return False
    
    def _create_resume_info(self, path: str) -> Optional[ResumeFile]:
        """创建简历信息对象"""
        try:
            stat = os.stat(path)
            filename = os.path.basename(path)
            
            # 检测语言
            language = self._detect_language(filename)
            
            # 获取文件类型
            ext = filename.split('.')[-1].lower()
            
            return ResumeFile(
                path=path,
                filename=filename,
                modified_time=datetime.fromtimestamp(stat.st_mtime),
                language=language,
                type=ext
            )
        except Exception:
            return None
    
    def _detect_language(self, filename: str) -> str:
        """根据文件名检测语言"""
        filename_lower = filename.lower()
        
        # 中文简历
        if '简历' in filename or '中文' in filename or '_cn' in filename_lower or '_zh' in filename_lower:
            return 'zh'
        
        # 丹麦语简历
        if 'dansk' in filename_lower or 'dk' in filename_lower or 'danish' in filename_lower:
            return 'da'
        
        # 默认英文
        return 'en'


class ResumeRefinementEngine:
    """
    简历精修引擎
    分析简历 → 给出建议 → 自动修改 → 用户确认
    """
    
    def __init__(self, openai_client):
        self.client = openai_client
    
    def analyze_resume(self, resume_text: str) -> Dict:
        """
        深度分析简历，返回结构化建议
        """
        prompt = f"""
        请深度分析以下简历，提供详细的精修建议。
        
        简历内容：
        {resume_text}
        
        请按以下格式返回分析结果（JSON格式）：
        {{
            "summary": "简历整体评价",
            "suggestions": [
                {{
                    "type": "auto|manual",
                    "category": "format|content|language|structure",
                    "location": "具体位置（如：工作经历第2条）",
                    "original": "原文",
                    "issue": "问题描述",
                    "suggestion": "修改建议",
                    "auto_fix": "如果是auto类型，提供自动修改后的文本"
                }}
            ],
            "auto_fixes": ["可以自动修改的项目列表"],
            "manual_fixes": ["需要用户手动修改的项目列表"],
            "improved_resume": "修改后的完整简历（仅包含auto类型的修改）"
        }}
        
        分类说明：
        - auto: AI可以自动修改（如格式问题、动词强化、语法错误）
        - manual: 需要用户提供信息才能修改（如补充具体数据、量化成果）
        """
        
        # 这里调用OpenAI API进行分析
        # 返回结构化的建议
        
        return {
            "summary": "分析完成",
            "suggestions": [],
            "auto_fixes": [],
            "manual_fixes": [],
            "improved_resume": resume_text
        }
    
    def apply_selected_fixes(self, resume_text: str, selected_fixes: List[int], suggestions: List[Dict]) -> str:
        """
        应用用户选择的修改
        selected_fixes: 用户选择的建议索引列表
        """
        improved = resume_text
        
        for idx in selected_fixes:
            if idx < len(suggestions):
                suggestion = suggestions[idx]
                if suggestion['type'] == 'auto' and 'auto_fix' in suggestion:
                    # 替换原文
                    improved = improved.replace(suggestion['original'], suggestion['auto_fix'])
        
        return improved


class JobPlatformConnector:
    """
    招聘平台连接器
    帮助用户连接各大招聘平台，获取职位推送
    """
    
    # 支持的招聘平台
    PLATFORMS = {
        'linkedin': {
            'name': 'LinkedIn',
            'icon': '💼',
            'setup_url': 'https://www.linkedin.com/mypreferences/d/settings/email',
            'email_patterns': ['linkedin.com', 'jobs-listings@linkedin.com'],
            'description': '全球最大的职业社交平台'
        },
        'jobindex': {
            'name': 'Jobindex',
            'icon': '🇩🇰',
            'setup_url': 'https://www.jobindex.dk/jobsoegning',
            'email_patterns': ['jobindex.dk'],
            'description': '丹麦最大招聘网站'
        },
        'jobnet': {
            'name': 'Jobnet',
            'icon': '🏛️',
            'setup_url': 'https://jobnet.dk',
            'email_patterns': ['jobnet.dk'],
            'description': '丹麦官方就业服务'
        },
        'stepstone': {
            'name': 'StepStone',
            'icon': '🇩🇪',
            'setup_url': 'https://www.stepstone.de',
            'email_patterns': ['stepstone.de', 'stepstone.dk'],
            'description': '德国/北欧招聘平台'
        },
        'indeed': {
            'name': 'Indeed',
            'icon': '🌐',
            'setup_url': 'https://www.indeed.com',
            'email_patterns': ['indeed.com'],
            'description': '全球职位搜索引擎'
        }
    }
    
    def get_setup_guide(self, platform_id: str) -> Dict:
        """获取平台设置指南"""
        platform = self.PLATFORMS.get(platform_id)
        if not platform:
            return None
        
        return {
            'name': platform['name'],
            'icon': platform['icon'],
            'setup_steps': [
                f"1. 访问 {platform['setup_url']}",
                "2. 登录您的账号",
                "3. 设置职位提醒（Job Alerts）",
                "4. 确保使用您要连接的邮箱地址",
                "5. 保存设置，开始接收职位推送邮件"
            ],
            'description': platform['description']
        }
    
    def detect_connected_platforms(self, email_reader) -> List[str]:
        """
        通过分析邮件自动检测用户已连接的招聘平台
        """
        connected = []
        
        # 读取最近100封邮件，检测发件人
        emails = email_reader.fetch_recent_emails(limit=100)
        
        for email in emails:
            sender = email.get('from', '').lower()
            
            for platform_id, platform in self.PLATFORMS.items():
                for pattern in platform['email_patterns']:
                    if pattern in sender:
                        if platform_id not in connected:
                            connected.append(platform_id)
                        break
        
        return connected


class OnboardingFlow:
    """
    完整的用户引导流程
    """
    
    def __init__(self, openai_client=None):
        self.discovery = ResumeDiscovery()
        self.refinement = ResumeRefinementEngine(openai_client)
        self.platform_connector = JobPlatformConnector()
    
    def start_onboarding(self) -> Dict:
        """
        开始引导流程 - 第一步：发现简历
        """
        print("🔍 正在扫描您的电脑，寻找简历文件...")
        
        resumes = self.discovery.find_resumes()
        
        if not resumes:
            return {
                'step': 'no_resume_found',
                'message': '未找到简历文件，请手动上传',
                'action': 'manual_upload'
            }
        
        # 返回最新版本的简历
        latest = resumes[0]
        
        return {
            'step': 'resume_found',
            'message': f'欢迎使用 JobMatchAI！',
            'latest_resume': {
                'path': latest.path,
                'filename': latest.filename,
                'modified': latest.display_name,
                'language': latest.language
            },
            'all_resumes': [
                {'path': r.path, 'filename': r.filename, 'modified': r.display_name}
                for r in resumes[:5]  # 只显示前5个
            ],
            'action': 'confirm_resume'
        }
    
    def refine_resume(self, resume_path: str) -> Dict:
        """
        第二步：精修简历
        """
        # 读取简历内容
        resume_text = self._read_resume_file(resume_path)
        
        # 分析并生成建议
        analysis = self.refinement.analyze_resume(resume_text)
        
        return {
            'step': 'refine_resume',
            'summary': analysis['summary'],
            'suggestions': analysis['suggestions'],
            'auto_fixes_count': len(analysis['auto_fixes']),
            'manual_fixes_count': len(analysis['manual_fixes']),
            'action': 'review_suggestions'
        }
    
    def apply_refinement(self, resume_path: str, selected_fixes: List[int], suggestions: List[Dict]) -> Dict:
        """
        应用用户选择的修改
        """
        resume_text = self._read_resume_file(resume_path)
        improved = self.refinement.apply_selected_fixes(resume_text, selected_fixes, suggestions)
        
        # 保存修改后的简历
        output_path = self._save_improved_resume(resume_path, improved)
        
        return {
            'step': 'refinement_complete',
            'message': '简历精修完成！',
            'improved_resume_path': output_path,
            'improved_text': improved,
            'action': 'connect_platforms'
        }
    
    def setup_job_platforms(self, email_reader) -> Dict:
        """
        第三步：设置招聘平台连接
        """
        # 自动检测已连接的平台
        connected = self.platform_connector.detect_connected_platforms(email_reader)
        
        # 获取未连接的平台列表
        unconnected = [
            {'id': pid, **info}
            for pid, info in self.platform_connector.PLATFORMS.items()
            if pid not in connected
        ]
        
        return {
            'step': 'setup_platforms',
            'connected_platforms': connected,
            'unconnected_platforms': unconnected,
            'message': f'检测到您已连接 {len(connected)} 个招聘平台',
            'action': 'configure_platforms'
        }
    
    def _read_resume_file(self, path: str) -> str:
        """读取简历文件内容"""
        ext = path.split('.')[-1].lower()
        
        if ext == 'pdf':
            return self._read_pdf(path)
        elif ext in ['docx', 'doc']:
            return self._read_docx(path)
        else:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
    
    def _read_pdf(self, path: str) -> str:
        """读取PDF文件"""
        try:
            import fitz
            doc = fitz.open(path)
            text = ""
            for page in doc:
                text += page.get_text()
            return text
        except:
            return ""
    
    def _read_docx(self, path: str) -> str:
        """读取DOCX文件"""
        try:
            from docx import Document
            doc = Document(path)
            return "\n".join([p.text for p in doc.paragraphs])
        except:
            return ""
    
    def _save_improved_resume(self, original_path: str, improved_text: str) -> str:
        """保存改进后的简历"""
        directory = os.path.dirname(original_path)
        filename = os.path.basename(original_path)
        name, ext = os.path.splitext(filename)
        
        output_path = os.path.join(directory, f"{name}_improved{ext}")
        
        # 保存为文本文件（简化版）
        txt_path = os.path.join(directory, f"{name}_improved.txt")
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(improved_text)
        
        return txt_path


# === 使用示例 ===

if __name__ == "__main__":
    # 模拟完整的用户引导流程
    
    print("=" * 60)
    print("🚀 JobMatchAI 智能引导系统")
    print("=" * 60)
    
    flow = OnboardingFlow()
    
    # 第一步：发现简历
    result = flow.start_onboarding()
    
    if result['step'] == 'resume_found':
        print(f"\n✅ {result['message']}")
        print(f"📄 发现最新简历: {result['latest_resume']['modified']}")
        print(f"   路径: {result['latest_resume']['path']}")
        
        # 用户确认使用这个简历
        print("\n🤔 用户点击: [使用此简历]")
        
        # 第二步：精修简历
        print("\n🔧 正在分析简历并生成精修建议...")
        # refine_result = flow.refine_resume(result['latest_resume']['path'])
        
        print("\n📋 分析完成！发现以下可改进项：")
        print("   - 3项可自动修改（格式、动词强化）")
        print("   - 2项需手动补充（量化成果、具体数据）")
        
        print("\n🤔 用户选择: [接受所有自动修改]")
        
        # 第三步：连接招聘平台
        print("\n🔗 正在检测已连接的招聘平台...")
        print("   ✅ LinkedIn - 已连接")
        print("   ✅ Jobindex - 已连接")
        print("   ❌ StepStone - 未连接")
        
        print("\n🎉 设置完成！JobMatchAI 已准备就绪")
        print("   每天会自动读取新职位并推送匹配结果")
    else:
        print(f"❌ {result['message']}")
